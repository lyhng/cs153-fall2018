package wci.intermediate;

/**
 *
 *
 * <h1>SymTab</h1>
 *
 * <p>The framework interface that represents the symbol table.
 *
 * <p>Copyright (c) 2009 by Ronald Mak
 *
 * <p>For instructional purposes only. No warranties.
 */
public interface SymTab {}
