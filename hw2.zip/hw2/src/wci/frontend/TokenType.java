package wci.frontend;

/**
 *
 *
 * <h1>TokenType</h1>
 *
 * <p>The token type interface.
 *
 * <p>Copyright (c) 2009 by Ronald Mak
 *
 * <p>For instructional purposes only. No warranties.
 */
public interface TokenType {}
